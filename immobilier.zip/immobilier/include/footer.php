<footer class="bg-dark py-5 fixed-bottom">
    <div class="container">
        <div class="small text-center text-muted">Made with ❤️ and 🍫 par Karla Gergelova © 2019 tous droits réservés</div>
    </div>                
</footer>